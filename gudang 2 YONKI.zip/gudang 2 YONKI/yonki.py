# =========================
# OPTIMASI PENJADWALAN KARYAWAN
# Menggunakan PuLP
# =========================

import pulp

# -------------------------
# Data Karyawan
# -------------------------
karyawan = [
    "Budi", "Dewa", "Eka", "Gani", "Hana",
    "Irma", "Kiki", "Lala", "Made", "Oki",
    "Putra", "Qori", "Rina"
]

shift = ["Pagi", "Siang", "Malam"]

# Gaji per jam
gaji = {
    "Budi": 35000, "Dewa": 30000, "Eka": 32000,
    "Gani": 30000, "Hana": 35000, "Irma": 33000,
    "Kiki": 30000, "Lala": 36000, "Made": 32000,
    "Oki": 33000, "Putra": 34000, "Qori": 30000,
    "Rina": 36000
}

jam_kerja = 8

# -------------------------
# Model Optimasi
# -------------------------
model = pulp.LpProblem("Penjadwalan_Karyawan", pulp.LpMinimize)

# Variabel keputusan (0/1)
x = pulp.LpVariable.dicts(
    "Assign",
    [(k, s) for k in karyawan for s in shift],
    cat="Binary"
)

# -------------------------
# Fungsi Tujuan
# -------------------------
model += pulp.lpSum(
    gaji[k] * jam_kerja * x[(k, s)]
    for k in karyawan for s in shift
)

# -------------------------
# Kendala
# -------------------------

# Setiap shift harus diisi minimal 4 karyawan
for s in shift:
    model += pulp.lpSum(x[(k, s)] for k in karyawan) == 4

# Setiap karyawan hanya boleh bekerja 1 shift
for k in karyawan:
    model += pulp.lpSum(x[(k, s)] for s in shift) <= 1

# -------------------------
# Penyelesaian
# -------------------------
model.solve()

# -------------------------
# Output
# -------------------------
total_biaya = 0
print("=== HASIL OPTIMASI (PuLP) ===")
for k in karyawan:
    for s in shift:
        if x[(k, s)].value() == 1:
            biaya = gaji[k] * jam_kerja
            total_biaya += biaya
            print(f"{k:6} | {s:6} | Rp {biaya}")

print(f"\nTotal Biaya Minimum: Rp {total_biaya}")